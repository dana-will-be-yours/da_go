# da_go GitHub 直接更新修正包

用途：修正 `da_go` 目前驗證與部署版本不一致的阻斷點，讓 GitHub Pages workflow 可部署 `1.13.2-direct-split`。

此包不含精簡版 `game-modular.js`，不會覆蓋遊戲本體。

## 需要上傳/覆蓋的檔案

在 GitHub 倉庫 `dana-will-be-yours/da_go` 內，直接上傳或覆蓋下列檔案：

```text
package.json
tools/validate-public-page.js
tools/validate-playable-architecture.js
tools/patch-game-html-runtime-url.js
```

## 直接在 GitHub 網頁操作

1. 進入 `da_go` 倉庫。
2. 逐一打開對應路徑。
3. 若檔案存在，按 Edit，全部取代為本包檔案內容。
4. 若檔案不存在，按 Add file > Create new file，依路徑建立。
5. Commit message 使用：

```text
Fix direct split validation and runtime URL
```

## 本機驗證

```powershell
node tools/patch-game-html-runtime-url.js
npm test
```

## 注意

`game.html` 的 runtime URL 目前若仍是舊版，可執行：

```powershell
node tools/patch-game-html-runtime-url.js
```

此腳本會把：

```text
assets/game-runtime.js?v=<任何舊版本>
```

改成：

```text
assets/game-runtime.js?v=1.13.2-direct-split
```
